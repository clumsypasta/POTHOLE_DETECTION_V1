# CPEWEBSAYT

A Pen created on CodePen.io. Original URL: [https://codepen.io/TANISH-AHIRE/pen/OJqgeby](https://codepen.io/TANISH-AHIRE/pen/OJqgeby).

INTERFACE FOR UPLOADING AND INFERRING IMAGES